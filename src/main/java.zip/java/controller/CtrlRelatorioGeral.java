package controller;

import java.util.List;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Context;
import model.AvaliaLinha;

@Path("\relatoriogeral")
public class CtrlRelatorioGeral {

	List<AvaliaLinha> avaliacoes;
	
	@Context
	private HttpServletRequest request;

	@Context
	private HttpServletResponse response;
	
	public CtrlRelatorioGeral() {
	}
	
	
}
