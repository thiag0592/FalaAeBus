package model.exception;

public class FluxoDeEstadoException extends RuntimeException {

    public FluxoDeEstadoException(String mensagem) {
        super(mensagem);
    }
}
